<?php

define("DSN", "mysql:host=localhost;dbname=php_project;charset=utf8mb4");

define("DB_USER", "if0_42852819");

define("DB_PASS", "RdHoxOdZOzXnVuJ");
